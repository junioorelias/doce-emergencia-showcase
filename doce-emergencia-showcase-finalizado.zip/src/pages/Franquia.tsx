import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Handshake, Clock, Star, TrendingUp, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Franquia = () => {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    cidade: ""
  });
  const [loading, setLoading] = useState(false);
  const [enviado, setEnviado] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.email || !formData.cidade) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos para continuar",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    // Simula envio dos dados
    setTimeout(() => {
      setEnviado(true);
      setLoading(false);
      toast({
        title: "🎉 Interesse registrado!",
        description: "Você receberá prioridade exclusiva por e-mail",
      });
    }, 2000);
  };

  if (enviado) {
    return (
      <div className="min-h-screen bg-doce-light-gray pt-20">
        <div className="container mx-auto px-4 py-16">
          <Card className="max-w-2xl mx-auto p-12 text-center bg-doce-white shadow-xl">
            <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
            
            <h1 className="text-3xl font-bold text-doce-brown mb-4">
              Interesse Registrado! 🎯
            </h1>
            
            <p className="text-lg text-doce-brown/80 mb-8 leading-relaxed">
              <strong>Seu interesse foi registrado.</strong> Assim que as primeiras 
              oportunidades forem liberadas, você receberá prioridade exclusiva por e-mail.
            </p>
            
            <div className="bg-doce-yellow/10 p-6 rounded-xl border border-doce-yellow/20">
              <p className="text-doce-brown font-medium">
                📧 Fique atento ao seu e-mail: <strong>{formData.email}</strong>
              </p>
            </div>
            
            <Button
              onClick={() => {
                setEnviado(false);
                setFormData({ nome: "", email: "", cidade: "" });
              }}
              variant="outline"
              className="mt-8"
            >
              Voltar ao Início
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-doce-light-gray pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Header com Urgência */}
        <div className="text-center mb-12">
          <div className="bg-doce-yellow inline-flex items-center gap-2 px-4 py-2 rounded-full text-doce-brown font-semibold mb-4">
            🚀 EXCLUSIVO
          </div>
          
            <h1 className="text-4xl md:text-5xl font-bold text-doce-brown mb-4 leading-tight">
	              Seja um dos Primeiros a Fazer Parte da <span className="text-doce-yellow">Doce Emergência!</span>
	            </h1>
	            
	            <p className="text-xl text-doce-brown/90 max-w-3xl mx-auto leading-relaxed">
	              Uma Oportunidade Única de Empreender no Mercado de Doces Gourmet com um Modelo de Negócio Promissor e de Alto Impacto.
	            </p>
        </div>

	        {/* Seção 1: A Revolução da Doçura */}
	        <div className="max-w-4xl mx-auto mb-12">
	          <h2 className="text-3xl font-bold text-doce-brown mb-4 text-center">
	            O Mercado Pede Mais, e Nós Entregamos.
	          </h2>
	          <p className="text-lg text-doce-brown/80 text-center max-w-3xl mx-auto leading-relaxed">
	            A <strong>Doce Emergência</strong> nasceu de uma necessidade clara: a vontade inadiável por um doce gourmet de alta qualidade, entregue com agilidade e excelência. Em um mercado saturado de opções comuns, nosso modelo de negócio se destaca por ser focado na <strong>conveniência, na qualidade premium e na experiência do cliente</strong>.
	          </p>
	          <p className="text-lg text-doce-brown/80 text-center max-w-3xl mx-auto leading-relaxed mt-4">
	            Não vendemos apenas doces; vendemos <strong>soluções para momentos de emergência de doçura</strong>. Isso nos posiciona em um nicho de alto crescimento e fidelidade. Nossos produtos, feitos com ingredientes selecionados e receitas exclusivas, garantem um diferencial competitivo que se traduz em alta lucratividade.
	          </p>
	        </div>
	
	        {/* Seção 2: O Modelo de Negócio (Implícito) */}
	        <div className="max-w-4xl mx-auto mb-12 p-8 bg-doce-yellow/10 rounded-xl">
	          <h2 className="text-3xl font-bold text-doce-brown mb-4 text-center">
	            O Segredo do Nosso Sucesso
	          </h2>
	          <p className="text-lg text-doce-brown/80 text-center max-w-3xl mx-auto leading-relaxed">
	            Nosso modelo de operação foi desenhado para ser <strong>enxuto, escalável e altamente replicável</strong>. Utilizamos tecnologia de ponta (como o nosso sistema de pedidos integrado) para otimizar cada etapa, desde a produção até a entrega final. Isso permite que nossos parceiros se concentrem no que realmente importa: <strong>a qualidade do produto e o relacionamento com o cliente</strong>.
	          </p>
	          <p className="text-lg text-doce-brown/80 text-center max-w-3xl mx-auto leading-relaxed mt-4">
	            Embora os detalhes do nosso <em>know-how</em> sejam reservados aos nossos futuros franqueados, o que podemos revelar é que a estrutura é pensada para <strong>maximizar a margem de lucro</strong> e <strong>minimizar os custos operacionais</strong> tradicionais do setor. É um negócio de futuro, com foco em delivery e na experiência digital.
	          </p>
	        </div>
	
	        {/* Seção 3: A Lista de Espera - Sua Vantagem Competitiva */}
	        <Card className="max-w-2xl mx-auto p-8 bg-doce-white border-2 border-doce-yellow/20">
	          <div className="text-center mb-8">
	            <h2 className="text-2xl font-bold text-doce-brown mb-4">
	              Não Perca o Momento Certo: Entre na Lista de Espera Exclusiva.
	            </h2>
	            <p className="text-doce-brown/80 mb-6">
	              A demanda por franquias da Doce Emergência tem sido extraordinária. Para garantir que cada novo parceiro receba o suporte e a atenção que merece, estamos abrindo um número <strong>limitado</strong> de vagas para a nossa primeira onda de expansão.
	            </p>
	            <p className="text-doce-brown/80 font-semibold">
	              Ao se inscrever na nossa <strong>Lista de Espera Exclusiva</strong>, você garante a oportunidade de ser um dos primeiros a receber o nosso <strong>Plano de Expansão Detalhado</strong> e ter prioridade no processo de seleção.
	            </p>
	            <p className="text-xl font-bold text-doce-red mt-4">
	              Aja agora. O futuro da doçura espera por você.
	            </p>
	          </div>

          {/* Formulário */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="nome" className="block text-sm font-semibold text-doce-brown mb-2">
                Nome Completo *
              </label>
              <Input
                id="nome"
                name="nome"
                type="text"
                placeholder="Seu nome completo"
                value={formData.nome}
                onChange={handleInputChange}
                required
                className="placeholder:text-gray-500"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-doce-brown mb-2">
                E-mail *
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="placeholder:text-gray-500"
              />
            </div>

            <div>
              <label htmlFor="cidade" className="block text-sm font-semibold text-doce-brown mb-2">
                Cidade *
              </label>
              <Input
                id="cidade"
                name="cidade"
                type="text"
                placeholder="Sua cidade"
                value={formData.cidade}
                onChange={handleInputChange}
                required
                className="placeholder:text-gray-500"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-doce-yellow text-doce-brown hover:bg-doce-yellow/90 font-bold py-4 text-lg shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              {loading ? "Enviando..." : "🚀 Entrar na Lista de Espera"}
            </Button>
          </form>

	          <p className="text-xs text-gray-600 text-center mt-4">
	            * Ao enviar, você concorda em receber comunicações sobre oportunidades de franquia
	          </p>
	        </Card>
      </div>
    </div>
  );
};

export default Franquia;